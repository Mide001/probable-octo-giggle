100 Days Coding Challenge
four_cards__sectioning 
By Ogedengbe Isreal
